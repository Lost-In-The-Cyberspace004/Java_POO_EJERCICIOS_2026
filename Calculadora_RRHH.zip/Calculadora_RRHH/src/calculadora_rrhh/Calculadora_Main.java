package calculadora_rrhh;

import java.util.Scanner;

public class Calculadora_Main {
    public static void main(String[] args) {
        Scanner EntrUs = new Scanner(System.in);
        Calculadora_RRHH_Procesos Obj1 = new Calculadora_RRHH_Procesos();
        System.out.println(Obj1.NetoAPagar(67));
        System.out.println(Obj1.NetoAPagar(37));
    }
    
}
