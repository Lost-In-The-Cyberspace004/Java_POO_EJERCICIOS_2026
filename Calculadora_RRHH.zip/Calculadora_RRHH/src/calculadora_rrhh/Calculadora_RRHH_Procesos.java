package calculadora_rrhh;

import java.util.*;

public class Calculadora_RRHH_Procesos {
    
    double SalarioMinimo = 1500000;
    int diasLaborales = 30;
    double AuxTransporte = 249095;
    double SalarioBase = SalarioMinimo + AuxTransporte;
    
    public double SalarioDevengado(int DiasTrabajados){
        if(DiasTrabajados > 0){
            double SD = SalarioBase / diasLaborales * DiasTrabajados;
            return SD;
        }
        return 0;
    }
    
    public double SaludEmpleado(){
        double Salud = SalarioMinimo * 0.04;
        return Salud;
    }
    
    public double Pension(){
        double PensionCalculo = SalarioMinimo * 0.04;
        return PensionCalculo;
    }
    
    public double NetoAPagar(int DiasTrabajados){
        double ValorInicial = SalarioDevengado(DiasTrabajados);
        double NetoAPagarTrabajador = (ValorInicial + AuxTransporte) - (SaludEmpleado() + Pension());
        return NetoAPagarTrabajador;
    }
    
    public double Cesantias(int diasTrabajados){
        double cesantias = ((SalarioBase * diasTrabajados) / 360);
        return cesantias;
    }
    
    public double InteresesDeCesantias(int diasTrabajados){
        double Intereces = ((Cesantias(diasTrabajados) * diasTrabajados * 0.12) / 360);
        return Intereces;
    }
    
    public double PrimaDeServicios(int diasTrabajados){
        double Primas = ((SalarioBase * diasTrabajados) / 360);
        return Primas;
    }
    
    public double Vacaciones(int diasTrabajados){
        double VacacionesTrabajador = ((SalarioMinimo * diasTrabajados) / 720);
        return VacacionesTrabajador;
    }
    
}
