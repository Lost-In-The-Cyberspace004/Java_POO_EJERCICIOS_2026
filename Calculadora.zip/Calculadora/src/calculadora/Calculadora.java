package calculadora;

import java.util.Scanner;
import java.math.*;

class Operaciones {

    int contadora = 0;
    double[] Valores = new double[10];
    Scanner EntrUs = new Scanner(System.in);

    public double suma(int numerosOperar) {
        int acumulador = 0;
        for (int i = 0; i < numerosOperar; i++) {
            System.out.print(": ");
            int NumerosASumar = EntrUs.nextInt();
            acumulador = NumerosASumar + acumulador;
        }
        for (int j = 0; j < Valores.length; j++) {
            if (Valores[j] == 0) {
                Valores[j] = acumulador;
                contadora += 1;
                break;
            }
        }
        return acumulador;
    }

    public double resta(int numerosOperar) {
        int acumulador = 0;
        for (int i = 0; i < numerosOperar; i++) {
            System.out.print(": ");
            int NumerosR = EntrUs.nextInt();
            acumulador = NumerosR - acumulador;
            contadora += 1;
        }
        for (int j = 0; j < Valores.length; j++) {
            if (Valores[j] == 0) {
                Valores[j] = acumulador;
                break;
            }
        }
        return acumulador;
    }

    public double multiplicacion(double M) {
        int acumulador = 1;
        for (int i = 0; i < M; i++) {
            System.out.print(": ");
            int NumerosM = EntrUs.nextInt();
            acumulador = (NumerosM * acumulador);
            contadora += 1;
        }
        for (int j = 0; j < Valores.length; j++) {
            if (Valores[j] == 0) {
                Valores[j] = acumulador;
                break;
            }
        }
        return acumulador;
    }

    public double divicion(double D) {
        int acumulador = 1;
        for (int i = 0; i < D; i++) {
            System.out.print(": ");
            int NumerosD = EntrUs.nextInt();
            acumulador = NumerosD / acumulador;
            contadora += 1;
        }
        for (int j = 0; j < Valores.length; j++) {
            if (Valores[j] == 0) {
                Valores[j] = acumulador;
                break;
            }
        }
        return acumulador;
    }

    public double raiz(double raiz) {
        double raizNumero = Math.sqrt(raiz);
        for (int i = 0; i < Valores.length; i++) {
            if (Valores[i] == 0) {
                Valores[i] = raizNumero;
                contadora += 1;
                break;
            }
        }
        return raizNumero;
    }

    public double exponentes(double Numero1, double Exponente) {
        double exponenteNumero = Math.pow(Numero1, Exponente);
        for (int i = 0; i < Valores.length; i++) {
            if (Valores[i] == 0) {
                Valores[i] = exponenteNumero;
                contadora += 1;
                break;
            }
        }
        return exponenteNumero;
    }

    public double InversaMultiplicativa(double Valor) {
        double InvMult = (1 / Valor);
        for(int i = 0; i < Valores.length; i++){
            if(Valores[i] == 0){
                Valores[i] = InvMult;
                contadora += 1;
                break;
            }
        }
        return InvMult;
    }

    public void recorrerHistorial() {
        for (int i = 0; i < Valores.length; i++) {
            System.out.println(Valores[i]);
        }
        if (contadora >= 10) {
            Valores = null;
        }
    }

}

public class Calculadora {

    public static void main(String[] args) {
        Scanner EntrUs = new Scanner(System.in);
        System.out.print(" 1-) suma \n 2-) resta \n 3-) multiplicacion \n 4-) divicion \n 5-) raiz \n 6-) exponentes \n 7-) inversa multiplicativa");

        Operaciones obj1 = new Operaciones();

        int iterador = 0;
        while (iterador == 0) {
            System.out.print("\n Opcion: ");
            int Opcion = EntrUs.nextInt();
            switch (Opcion) {
                case 1:
                    System.out.print("Numeros a sumar: ");
                    int S = EntrUs.nextInt();
                    System.out.print(obj1.suma(S));
                    break;
                case 2:
                    System.out.print("Numeros a restar: ");
                    int R = EntrUs.nextInt();
                    System.out.print(obj1.resta(R));
                    break;
                case 3:
                    System.out.print("Numeros a multiplicar: ");
                    int M = EntrUs.nextInt();
                    System.out.print(obj1.multiplicacion(M));
                    break;
                case 4:
                    System.out.print("Numeros a dividir: ");
                    int D = EntrUs.nextInt();
                    System.out.print(obj1.divicion(D));
                    break;
                case 5:
                    System.out.print("Valor: ");
                    double NumeroR = EntrUs.nextDouble();
                    System.out.print(obj1.raiz(NumeroR));
                    break;
                case 6:
                    System.out.print("Valor: ");
                    double Numero1 = EntrUs.nextDouble();
                    System.out.print("Exponente: ");
                    double exponente = EntrUs.nextDouble();
                    System.out.print(obj1.exponentes(Numero1, exponente));
                    break;
                case 7:
                    System.out.print("Valor: ");
                    double valor = EntrUs.nextDouble();
                    System.out.print(obj1.InversaMultiplicativa(valor));
                    break;
                case 8:
                    obj1.recorrerHistorial();
                    break;
            }
        }

    }
}
