package buscador_de_nombres;

import java.util.*;

class procesoBusqueda {

    String Nombres;

    public procesoBusqueda(String NombreBuscarElement) {
        this.Nombres = NombreBuscarElement;
    }

    public void Nombres(procesoBusqueda[] ListaDeNombres, String NombreBuscar) {
        String Nombre = "";
        boolean encontrado = false;
        for(int i = 0; i < ListaDeNombres.length; i++){
            if(ListaDeNombres[i].getNombres().equalsIgnoreCase(NombreBuscar)){
                System.out.println("Encontrado correctamente" );
                Nombre = ListaDeNombres[i].getNombres();
                encontrado = true;
                System.out.print("Nombre encontrado: " + Nombre + "\n");
                break;
            }
        }
    }

    public String getNombres() {
        return Nombres;
    }
}

public class Buscador_De_Nombres {

    public static void main(String[] args) {
        Scanner EntrUs = new Scanner(System.in);

        procesoBusqueda Obj1 = new procesoBusqueda("i");
        procesoBusqueda[] ListaNombres = new procesoBusqueda[5];
        ListaNombres[0] = new procesoBusqueda("Jorge");
        ListaNombres[1] = new procesoBusqueda("Danna");
        ListaNombres[2] = new procesoBusqueda("Simon");
        ListaNombres[3] = new procesoBusqueda("Daniela");
        ListaNombres[4] = new procesoBusqueda("Karen");

        System.out.print("Nombre a buscar: ");
        String NombreBuscar = EntrUs.nextLine();
        Obj1.Nombres(ListaNombres, NombreBuscar);

    }

}
